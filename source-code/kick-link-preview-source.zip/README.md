# Kick Link Preview Extension

Kick.com için link önizleme eklentisi. YouTube, Instagram ve Twitter linklerini önizleme yapmanızı sağlar.

## Beta v0.1.11 (Hotfix)

### 🛠️ Düzeltmeler ve İyileştirmeler
- Enable Plugin özelliği düzeltildi (artık eklentiyi tamamen kapatabilirsiniz)
- YouTube ses seviyesi kontrolü düzeltildi (ayarlanan ses seviyesi doğru şekilde uygulanıyor)
- Dashboard sayfasında yaşanan çökme sorunu giderildi
- Preview boyutları optimize edildi:
  - YouTube: 480x360 (4:3 oranı)
  - Twitter: 450x450
  - Instagram: 400x600

### 🔜 Yakında Gelecek Özellikler
- Prnt.sc önizleme desteği
- Hızlıresim önizleme desteği
- Instagram videolarında otomatik oynatma

## Kurulum

### Chrome
1. `chrome://extensions` adresine gidin
2. Geliştirici modunu açın
3. "Load unpacked" ile `dist` klasörünü seçin

### Firefox
1. `about:debugging` adresine gidin
2. "This Firefox" sekmesine tıklayın
3. "Load Temporary Add-on" ile `dist-firefox` klasöründen manifest.json'u seçin

### Edge
1. `edge://extensions` adresine gidin
2. Geliştirici modunu açın
3. "Load unpacked" ile `dist-edge` klasörünü seçin

### Opera
1. `opera://extensions` adresine gidin
2. Geliştirici modunu açın
3. "Load unpacked" ile `dist` klasörünü seçin (Chrome versiyonu ile uyumlu)

## Build

Farklı tarayıcılar için build almak için:

```bash
# Chrome için
npm run build:chrome

# Firefox için
npm run build:firefox

# Edge için
npm run build:edge

# Opera için (Chrome build kullanılabilir)
npm run build:chrome
```

## Notlar

- Eklenti beta aşamasındadır, hatalar olabilir
- Bir sorunla karşılaşırsanız Enable Plugin özelliğini kapatıp yayına devam edebilirsiniz
- Ses seviyesi ayarı sadece YouTube videoları için geçerlidir

## 💻 Desteklenen Tarayıcılar
- Google Chrome
- Mozilla Firefox
- Microsoft Edge
- Opera

## 🛠️ Geliştirici Notları

### Build
```bash
# Chrome için build
npm run build:chrome

# Firefox için build
npm run build:firefox

# Edge için build
npm run build:edge

# Opera için build
npm run build:chrome
```

## 📝 Lisans
MIT License - Tüm hakları saklıdır. 